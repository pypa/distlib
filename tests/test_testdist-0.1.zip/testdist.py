"""
This is a test distribution for distlib.
"""

__author__  = "Test User <test.user@testusers.org>"
__status__  = "alpha"
__version__ = "0.1"
__date__    = "31 January 2013"

