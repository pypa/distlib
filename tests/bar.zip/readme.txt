Useful stuff is in the lib folder.
