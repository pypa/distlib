# benign module that should stay confined
OK = True
