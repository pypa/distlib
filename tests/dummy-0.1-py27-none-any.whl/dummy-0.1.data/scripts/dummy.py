#!python -E

from pprint import pprint

def postinstall(curr, prev):
    print('-- postinstall -------------:')
    pprint(curr)
    print('----------------------------')
    pprint(prev)
    print('----------------------------')

def preuninstall(curr, next):
    print('-- preuninstall ------------:')
    pprint(curr)
    print('----------------------------')
    pprint(next)
    print('----------------------------')

